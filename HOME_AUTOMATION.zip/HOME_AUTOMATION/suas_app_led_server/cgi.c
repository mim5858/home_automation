/*
 * Implementation of CGI handlers and adoption of generated JSON to sensors use case.
 */

#include "lwip/apps/httpd.h"
#include "lwip/opt.h"

#include "lwip/apps/fs.h"
#include "lwip/def.h"
#include "lwip/mem.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <bl_gpio.h>

#include "cJSON.h"

#include "cgi.h"
#include "leds.h"

static const char *
cgi_handler_led(int iIndex, int iNumParams, char *pcParam[], char *pcValue[])
{
  printf("iIndex: %d, iNumParams: %d, pcParam: %s, pcValue: %s\r\n", iIndex, iNumParams, pcParam[0], pcValue[0]);
  if (iNumParams == 2)
  {
    enum selected_led led;
    uint8_t state;

    /* check if valid led selected */
    if (!strcmp(pcParam[0], "led"))
    {
      if (!strcmp(pcValue[0], "red"))
      {
        led = LED_RED;
      }
      else if (!strcmp(pcValue[0], "green"))
      {
        led = LED_GREEN;
      }
      else if (!strcmp(pcValue[0], "blue"))
      {
        led = LED_BLUE;
      }
      else
      {
        return ERROR_404_ENDPOINT;
      }

      printf("Selected LED: %d\r\n", led);
    }
    else
    {
      return ERROR_404_ENDPOINT;
    }

    /* get wanted led state */
    if (!strcmp(pcParam[1], "state"))
    {
      state = strtol(pcValue[1], NULL, 10);

      if (state == 0)
      {
        state = LED_OFF;
      } else {
        state = LED_ON;
      }

      switch (led)
      {
      case LED_RED:
        led_state.state_led_red = state;
        break;
      case LED_GREEN:
        led_state.state_led_green = state;
        break;
      case LED_BLUE:
        led_state.state_led_blue = state;
        break;
      default:
        printf("Invalid LED selected");
      }

      printf("State: %d\r\n", state);

      // Apply LED state by using GPIO pins
      apply_led_state();
    }
    else
    {
      return ERROR_404_ENDPOINT;
    }
  }
  else
  {
    return ERROR_404_ENDPOINT;
  }
  return LED_ENDPOINT;
}

static const tCGI cgi_handlers[] = {
    {SET_LED_ENDPOINT,
     cgi_handler_led}};

/* opening (creating) the in real-time created file (page) */
int fs_open_custom(struct fs_file *file, const char *name)
{
  cJSON *json_response = NULL;
  char *response = NULL;
 if (!strcmp(name, LED_ENDPOINT))
{
    /* Allocate memory for the response */
    response = (char *)calloc(2048, sizeof(char));

    /* Start HTML structure */
    strcat(response, "<html><head><style>");
    strcat(response, "body { font-family: Arial, sans-serif; text-align: center; margin-top: 50px; background-color: #f9f9f9; }");
    strcat(response, ".card { display: inline-block; padding: 20px; border: 1px solid #ccc; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); width: 350px; margin: 0 auto; background: white; }");
    strcat(response, "h1 { font-size: 24px; color: #333; margin-bottom: 20px; }");
    strcat(response, ".button { display: flex; align-items: center; justify-content: center; text-decoration: none; padding: 20px 30px; margin: 20px 0; color: white; border-radius: 5px; font-weight: bold; font-size: 20px; }");
    strcat(response, ".button.on { background-color: #4CAF50; }");
    strcat(response, ".button.off { background-color: #f44336; }");
    strcat(response, ".button img { width: 20px; height: 20px; margin-right: 10px; }");
    strcat(response, "</style></head><body>");

    /* Add card container */
    strcat(response, "<div class='card'>");

    /* Add title */
    strcat(response, "<h1>HOME LIGHT CONTROLLER</h1>");

    /* Add links with styled buttons and icons */
    if (led_state.state_led_red == LED_OFF)
    {
        strcat(response, "<a href=\"" SET_LED_ENDPOINT "?led=red&state=1\" class='button on'>");
        strcat(response, "<img src='/images/turnon.png' alt='Red LED Icon'>TURN OFF OUTSIDE LIGHT</a>");
    }
    else
    {
        strcat(response, "<a href=\"" SET_LED_ENDPOINT "?led=red&state=0\" class='button off'>");
        strcat(response, "<img src='/images/turnon.png' alt='Red LED Icon'>TURN ON OUTSIDE LIGHT</a>");
    }

    if (led_state.state_led_green == LED_OFF)
    {
        strcat(response, "<a href=\"" SET_LED_ENDPOINT "?led=green&state=1\" class='button on'>");
        strcat(response, "<img src='/images/turnon.png' alt='Green LED Icon'>TURN OFF INDOOR LIGHT ONE</a>");
    }
    else
    {
        strcat(response, "<a href=\"" SET_LED_ENDPOINT "?led=green&state=0\" class='button off'>");
        strcat(response, "<img src='/images/turnon.png' alt='Green LED Icon'>TURN ON INDOOR LIGHT ONE</a>");
    }

    if (led_state.state_led_blue == LED_OFF)
    {
        strcat(response, "<a href=\"" SET_LED_ENDPOINT "?led=blue&state=1\" class='button on'>");
        strcat(response, "<img src='/images/turnon.png' alt='Blue LED Icon'>TURN OFF INDOOR LIGHT TWO</a>");
    }
    else
    {
        strcat(response, "<a href=\"" SET_LED_ENDPOINT "?led=blue&state=0\" class='button off'>");
        strcat(response, "<img src='/images/turnon.png' alt='Blue LED Icon'>TURN ON INDOOR LIGHT TWO</a>");
    }

    /* Close card container */
    strcat(response, "</div>");

    /* Close HTML structure */
    strcat(response, "</body></html>");
}


  else if (!strcmp(name, GET_LED_STATUS_ENDPOINT))
  {
    json_response = cJSON_CreateObject();
    cJSON_AddNumberToObject(json_response, "led_red", led_state.state_led_red);
    cJSON_AddNumberToObject(json_response, "led_green", led_state.state_led_green);
    cJSON_AddNumberToObject(json_response, "led_blue", led_state.state_led_blue);
    response = cJSON_PrintUnformatted(json_response);
  }
  else
  {
    /* send null if unknown URI */
    return 0;
  }

  int response_size = strlen(response);

  /* allocate memory */
  memset(file, 0, sizeof(struct fs_file));
  file->pextension = mem_malloc(response_size);
  if (file->pextension != NULL)
  {
    /* copy json to file handler */
    memcpy(file->pextension, response, response_size);
    file->data = (const char *)file->pextension;
    file->len = response_size;
    file->index = file->len;
    /* allow persisting connections */
    file->flags = FS_FILE_FLAGS_HEADER_PERSISTENT;
  }

  /* free no longer needed memory */
  if (json_response != NULL)
  {
    // delete json structure
    cJSON_Delete(json_response);
  }
  if (response != NULL)
  {
    free(response);
  }

  /* return whether data was sent */
  if (file->pextension != NULL)
  {
    return 1;
  }
  else
  {
    return 0;
  }
}

/* closing the custom file (free the memory) */
void fs_close_custom(struct fs_file *file)
{
  if (file && file->pextension)
  {
    mem_free(file->pextension);
    file->pextension = NULL;
  }
}

/* reading the custom file (nothing has to be done here, but function must be defined */
int fs_read_custom(struct fs_file *file, char *buffer, int count)
{
  LWIP_UNUSED_ARG(file);
  LWIP_UNUSED_ARG(buffer);
  LWIP_UNUSED_ARG(count);
  return FS_READ_EOF;
}

/* initialization functions */
void custom_files_init(void)
{
  printf("Initializing module for generating JSON output\r\n");
  /* Nothing to do as of now, should be initialized automatically */
}

void cgi_init(void)
{
  printf("Initializing module for CGI\r\n");
  http_set_cgi_handlers(cgi_handlers, LWIP_ARRAYSIZE(cgi_handlers));
}
