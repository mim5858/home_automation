// FreeRTOS
#include <FreeRTOS.h>
#include <task.h>
// Input/output
#include <stdio.h>

#include <inttypes.h>

#include <bl602_adc.h> //  ADC driver
#include <bl_adc.h>    //  ADC HAL
#include <bl_dma.h>    //  DMA HAL

#include <bl_gpio.h>
#include <hal_gpio.h>
#include <bl_timer.h>
#include <bl_sys.h>
#include <inttypes.h>
#include <bl_pwm.h>
#include <bl602_pwm.h>

// ADC definitions
#define ADC_GAIN1 ADC_PGA_GAIN_1
#define ADC_GAIN2 ADC_PGA_GAIN_1

// must be between 500 and 16,000
#define ADC_FREQUENCY 4096
#define NUMBER_OF_SAMPLES 1024
#define SINGLE_CHANNEL_CONVERSION_MODE 1

// Define LED pins
#define SERVO_R_PIN 17
#define SERVO_R_PWM_CHANNEL 2

// frequency
#define PWM_FREQUENCY 2000
#define PWM_FREQUENCY_DIVIDER 40

// LED GPIO pin (choose a suitable GPIO pin for your board)
#define LED_PIN 2
#define LED_PIN1 4 
 
 
#define ADC_THRESHOLD 1000 // Example threshold value
#define ADC_THRESHOLD01 21000
#define ADC_THRESHOLD1 18000 // 90 value
#define ADC_THRESHOLD2 10000  // 180
#define ADC_THRESHOLD3 3000  // 0

// Servo PWM pin and settings
//servo pin 14        // GPIO pin connected to the servo   // 50Hz frequency for servo
#define MIN_PULSE_WIDTH 1000 // 1ms minimum pulse width (in microseconds)
#define MAX_PULSE_WIDTH 2000 // 2ms maximum pulse width (in microseconds)
#define ADC_MAX_VALUE 4095   // Maximum ADC value (12-bit resolution)
#define PWM_CHANNEL 0        // PWM channel ID
#define PRIu32 __PRI32(u)

// GPIO pin connected to servo

// Define zones
#define ZONE_0 0
#define ZONE_1 1
#define ZONE_2 2
#define STOP_DUTY 7.5f
#define FORWARD_DUTY 9.0f
#define REVERSE_DUTY 6.0f

#define TIME_TO_POS_1 2000 // 2 seconds (home -> pos1)
#define TIME_TO_POS_2 4000 // 4 seconds (pos1 -> pos2)
#define TIME_TO_HOME 3000  // 6 seconds from pos2 -> home (approx)

int servoDirection = 0;
int resetTimer = 0;
/* function prototypes (needed for compiler, functions are implemented below) */

void init_adc(uint8_t pin);
uint32_t read_adc();

void init_led(uint8_t pin);
void control_led(uint8_t pin, uint8_t state);

void init_pwm()
{
  /* Initialize PWM:
     - Channel: SERVO_R_PWM_CHANNEL
     - Pin: SERVO_R_PIN
     - Frequency: 2000 Hz (will be divided by 40 to get 50 Hz)
  */
  if (bl_pwm_init(SERVO_R_PWM_CHANNEL, SERVO_R_PIN, PWM_FREQUENCY) < 0)
  {
    printf("PWM init error: Frequency may be out of range in the SDK driver.\n");
    return;
  }

  // Set frequency divider to achieve 50 Hz
  PWM_Channel_Set_Div(SERVO_R_PWM_CHANNEL, PWM_FREQUENCY_DIVIDER);

  // Start PWM operations
  bl_pwm_start(SERVO_R_PWM_CHANNEL);
}
void set_servo_angle(int angle)
{
  // Constrain angle to [0, 270]
  if (angle < 0)
    angle = 0;
  if (angle > 270)
    angle = 270;

  // Map angle to duty cycle: 0° -> 5%, 270° -> 10%
  // Range in duty = 5% total (from 5% to 10%)
  float duty_percent = 5.0f + ((float)angle * 5.0f) / 270.0f;

  // Optional: Clamp duty_percent to [5, 10]
  if (duty_percent < 5.0f)
    duty_percent = 5.0f;
  if (duty_percent > 10.0f)
    duty_percent = 10.0f;

  // Set PWM duty cycle
  bl_pwm_set_duty(SERVO_R_PWM_CHANNEL, duty_percent);
}

typedef enum
{
  SERVO_HOME = 0,
  SERVO_POS_1,
  SERVO_POS_2
} servo_pos_t;

static servo_pos_t current_servo_pos = SERVO_HOME;

void set_servo_speed(float duty_percent)
{
  if (duty_percent < 5.0f)
    duty_percent = 5.0f;
  if (duty_percent > 10.0f)
    duty_percent = 10.0f;

  bl_pwm_set_duty(SERVO_R_PWM_CHANNEL, duty_percent);
}

/**
 * Moves servo at `duty_percent` for `ms` milliseconds, then stops.
 */
void move_servo_for_time(float duty_percent, int ms)
{
  set_servo_speed(duty_percent);
  vTaskDelay(ms / portTICK_PERIOD_MS);
  set_servo_speed(STOP_DUTY);
}
/*   void task_servo_pwm(void *pvParameters)
{
    printf("Servo PWM task started\n");
    init_pwm();

    // Set the servo to the initial HOME position
    set_servo_angle(0); // Assuming 0° is the default position
    current_servo_pos = SERVO_HOME;

    while (1)
    {
        uint32_t servo_value = read_adc(); // Read the ADC value

        // Logic for controlling the servo based on ADC value
        if (servo_value > ADC_THRESHOLD1)
        {
            printf("ADC > THRESHOLD1: Moving forward for 2 seconds\n");
            move_servo_for_time(FORWARD_DUTY, TIME_TO_POS_1); // Rotate forward for 2 seconds
            printf("Returning to default position\n");
             set_servo_speed(STOP_DUTY);
            // move_servo_for_time(REVERSE_DUTY, TIME_TO_POS_1); // Return to home
        }
        else if (servo_value > ADC_THRESHOLD2 && servo_value <= ADC_THRESHOLD1)
        {
            printf("THRESHOLD2 < ADC <= THRESHOLD1: Moving forward for 4 seconds\n");
            move_servo_for_time(FORWARD_DUTY, TIME_TO_POS_2); // Rotate forward for 4 seconds
            printf("Returning to default position\n");
             set_servo_speed(STOP_DUTY);
           // move_servo_for_time(REVERSE_DUTY, TIME_TO_POS_2); // Return to home
        }
        else if (servo_value < ADC_THRESHOLD3)
        {
            printf("ADC < THRESHOLD3: Moving back to HOME position\n");
            set_servo_angle(0); // Immediately set to the default position
        }
        else
        {
            printf("ADC in undefined range: No action\n");
        }

        // Delay to prevent repeated actions
        vTaskDelay(500 / portTICK_PERIOD_MS);
    }

    // Should never reach here in a FreeRTOS task
    printf("Servo task exiting unexpectedly.\n");
    vTaskDelete(NULL);
}
  */
void task_servo_pwm(void *pvParameters)
{
  printf("Servo PWM task started\n");
  init_pwm();

  // Start in SERVO_HOME
  current_servo_pos = SERVO_HOME;

  while (1)
  {
    uint32_t servo_value = read_adc();

    if ((servo_value >= ADC_THRESHOLD01))
    {
      current_servo_pos = SERVO_HOME;
      printf("SERVO HOME SELECTED");
    }
    else if ((servo_value > 1000 && servo_value < ADC_THRESHOLD01))
    {
      current_servo_pos = SERVO_POS_1;
      printf("SERVO POS 1 SELECTED");
    }

    else if ((servo_value < 1000))
    {
      current_servo_pos = SERVO_POS_2;
      printf("SERVO POS 2 SELECTED");
    }

    switch (current_servo_pos)
    {
    case SERVO_HOME:
      // If ADC > THRESHOLD1 => move servo 2s forward from home => SERVO_POS_1
      if (servoDirection == 1)
      {
        printf("RESET MODE....");
        move_servo_for_time(REVERSE_DUTY, resetTimer);
      }
      printf("Stage1\n");
      move_servo_for_time(FORWARD_DUTY, 1800);

      resetTimer = 1800;
      servoDirection = 1;

      while (servo_value >= ADC_THRESHOLD01)
      {
        servo_value = read_adc();
        continue;
      }

      if ((servo_value > 1000 && servo_value < ADC_THRESHOLD01))
      {
        current_servo_pos = SERVO_POS_1;
        printf("Shifted to pos 1");
      }

      else if ((servo_value <1000))
      {
        current_servo_pos = SERVO_POS_2;
        printf("Shifted to pos 2");
      }

      break;

    case SERVO_POS_1:
      // If ADC < THRESHOLD2 => move servo 4s forward => SERVO_POS_2

      if (servoDirection == 1)
      {
        printf("RESET MODE....");
        move_servo_for_time(REVERSE_DUTY, resetTimer);
      }

      printf("Moving from POS_1 to POS_2 (4s forward)\n");
      move_servo_for_time(FORWARD_DUTY, 3600);

      resetTimer = 3600;
      servoDirection = 1;

      while ((servo_value > 1000 && servo_value < ADC_THRESHOLD01))
      {
        servo_value = read_adc();
        continue;
      }

      if (servo_value >= ADC_THRESHOLD01)
      {
        current_servo_pos = SERVO_HOME;
        printf("Shifted to Home");
      }

      else if ((servo_value <1000))
      {
        current_servo_pos = SERVO_POS_2;
        printf("Shifted to pos 2");
      }

      break;

    case SERVO_POS_2:
      // If ADC < THRESHOLD3 => move servo back home

      move_servo_for_time(REVERSE_DUTY, resetTimer);
      current_servo_pos = SERVO_HOME;

      resetTimer = 0;
      servoDirection = 0;

      while (servo_value < 1000)
      {
        servo_value = read_adc();
        continue;
      }

      if (servo_value >= ADC_THRESHOLD01)
      {
        current_servo_pos = SERVO_HOME;
        printf("Shifted to Home");
      }

      else if ((servo_value > 1000 && servo_value <ADC_THRESHOLD01))
      {
        current_servo_pos = SERVO_POS_1;
        printf("Shifted to pos 1");
      }

      break;

    default:
      // Fallback: if we ever land here, reset to home
      printf("Invalid servo state, resetting to HOME.\n");
      current_servo_pos = SERVO_HOME;
      break;
    }

    // Delay so we don't spam the ADC or redo the same command repeatedly
    vTaskDelay(500 / portTICK_PERIOD_MS);
  }

  // Should never get here in typical FreeRTOS
  printf("Servo outside loop.\n");
  vTaskDelete(NULL);
}

/* ADC task */
void task_adc(void *pvParameters)
{
  printf("ADC task started\r\n");

  // Set GPIO pin for ADC. You can change this to any pin that supports ADC and has a sensor connected.
  init_adc(5);

  printf("ADC initialized\r\n");

  // Initialize LED GPIO
  init_led(LED_PIN);
  

  // wait until initialization finished
  vTaskDelay(150 / portTICK_PERIOD_MS);

  // constantly print current ADC values
  while (1)
  {
    uint32_t adc_value = read_adc();

    printf("Current value of digitized analog signal: %" PRIu32 "\r\n", read_adc());

    // Turn LED on if ADC value exceeds threshold, else turn it off
    if (adc_value < ADC_THRESHOLD)
    {
      control_led(LED_PIN, 1);
        }
    else
    {
      control_led(LED_PIN, 0);
       }
   
  
  if (adc_value < ADC_THRESHOLD)
    {
      
      control_led(LED_PIN1, 1);
      
    }
    else
    {
      
      control_led(LED_PIN1, 0);
      
    }
 
    vTaskDelay(5000 / portTICK_PERIOD_MS);
  }

  // should never happen but would delete the task and free allocated resources
  vTaskDelete(NULL);
}

static int set_adc_gain(uint32_t gain1, uint32_t gain2)
{
  // read configuration hardware register
  uint32_t reg = BL_RD_REG(AON_BASE, AON_GPADC_REG_CONFIG2);

  // set ADC gain bits
  reg = BL_SET_REG_BITS_VAL(reg, AON_GPADC_PGA1_GAIN, gain1);
  reg = BL_SET_REG_BITS_VAL(reg, AON_GPADC_PGA2_GAIN, gain2);

  // set chop mode
  if (gain1 != ADC_PGA_GAIN_NONE || gain2 != ADC_PGA_GAIN_NONE)
  {
    reg = BL_SET_REG_BITS_VAL(reg, AON_GPADC_CHOP_MODE, 2);
  }
  else
  {
    reg = BL_SET_REG_BITS_VAL(reg, AON_GPADC_CHOP_MODE, 1);
  }

  // enable ADC amplifier
  reg = BL_CLR_REG_BIT(reg, AON_GPADC_PGA_VCMI_EN);
  if (gain1 != ADC_PGA_GAIN_NONE || gain2 != ADC_PGA_GAIN_NONE)
  {
    reg = BL_SET_REG_BIT(reg, AON_GPADC_PGA_EN);
  }
  else
  {
    reg = BL_CLR_REG_BIT(reg, AON_GPADC_PGA_EN);
  }

  // update ADC configuration hardware register
  BL_WR_REG(AON_BASE, AON_GPADC_REG_CONFIG2, reg);
  return 0;
}

// NOTE: pin must be of the following 4, 5, 6, 9, 10, 11, 12, 13, 14, 15
// Otherwise you may damage your device!
void init_adc(uint8_t pin)
{
  // Ensure valid pin was selected
  switch (pin)
  {
  case 4:
  case 5:
  case 6:
  case 9:
  case 10:
  case 11:
  case 12:
  case 13:
  case 14:
  case 15:
    break;
  default:
    printf("Invalid pin selected for ADC\r\n");
    return;
  }

  // set frequency and single channel conversion mode
  bl_adc_freq_init(SINGLE_CHANNEL_CONVERSION_MODE, ADC_FREQUENCY);

  // initialize GPIO pin for single channel conversion mode
  bl_adc_init(SINGLE_CHANNEL_CONVERSION_MODE, pin);

  // enable ADC gain
  set_adc_gain(ADC_GAIN1, ADC_GAIN2);

  // initialize DMA for the ADC channel and for single channel conversion mode
  bl_adc_dma_init(SINGLE_CHANNEL_CONVERSION_MODE, NUMBER_OF_SAMPLES);

  // configure GPIO pin as ADC input
  bl_adc_gpio_init(pin);

  // mark pin and ADC as configured
  int channel = bl_adc_get_channel_by_gpio(pin);
  adc_ctx_t *ctx = bl_dma_find_ctx_by_channel(ADC_DMA_CHANNEL);
  ctx->chan_init_table |= (1 << channel);

  // start reading process
  bl_adc_start();
}

uint32_t read_adc()
{
  // array storing samples statically
  static uint32_t adc_data[NUMBER_OF_SAMPLES];

  // get DMA context for ADC channel to read data
  adc_ctx_t *ctx = bl_dma_find_ctx_by_channel(ADC_DMA_CHANNEL);

  // return if sampling failed or did not finish
  if (ctx->channel_data == NULL)
  {
    return 0;
  }

  // copy read samples from memory written dynamically by DMA to static array
  memcpy(
      (uint8_t *)adc_data,
      (uint8_t *)(ctx->channel_data),
      sizeof(adc_data));

  // calculate mean value
  uint32_t sum = 0;
  for (int i = 0; i < NUMBER_OF_SAMPLES; i++)
  {
    // scale up sample
    uint32_t scaled = ((adc_data[i] & 0xFFFF) * 32000) >> 16;
    sum += scaled;
  }

  return sum / NUMBER_OF_SAMPLES;
}
/* Initialize LED GPIO as output */
void init_led(uint8_t pin)
{
  bl_gpio_enable_output(pin, 0, 0);
  printf("LED initialized on GPIO pin %d\r\n", pin);
}

/* Control LED state: 1 for ON, 0 for OFF */
void control_led(uint8_t pin, uint8_t state)
{
  if (state)
  {
    bl_gpio_output_set(pin, 1); // Set GPIO HIGH
  }
  else
  {
    bl_gpio_output_set(pin, 0); // Set GPIO LOW
  }
}
