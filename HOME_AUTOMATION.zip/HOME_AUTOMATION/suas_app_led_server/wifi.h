#ifndef WIFI_H
#define WIFI_H

// Warning: do not use hardcoded credentials in production code!
#define WIFI_SSID "BL602_AP"
#define WIFI_PW "12345678"

#endif